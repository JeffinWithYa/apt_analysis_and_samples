def extract_valid_opcodes(input_file, output_file, valid_opcodes):
    try:
        with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
            for line in infile:
                opcode = line.strip()  # Remove leading/trailing whitespace
                # Check if the opcode is in the valid opcodes list
                if opcode in valid_opcodes:
                    outfile.write(opcode + '\n')  # Save the valid opcode to the output file
        print(f"Valid opcodes extracted and saved to {output_file}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    input_filename = "admin38.opcode"  # Replace with your input filename
    output_filename = "admin38_revised.opcode"  # Desired output filename

    # List of valid x86 opcodes
    valid_opcodes = {
        "MOV", "PUSH", "POP", "XCHG", "LEA",
        "ADD", "SUB", "MUL", "DIV", "INC", "DEC",
        "AND", "OR", "XOR", "NOT", "SHL", "SHR",
        "JMP", "JE", "JNE", "JG", "JL", "CALL", "RET",
        "CMP", "TEST",
        "MOVSB", "MOVSW", "CMPSB", "CMPSW", "LODSB", "LODSW", "STOSB", "STOSW",
        "BSF", "BSR", "BT",
        "HLT", "NOP", "WAIT", "ESC"
    }

    extract_valid_opcodes(input_filename, output_filename, valid_opcodes)

