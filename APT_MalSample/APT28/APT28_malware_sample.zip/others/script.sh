#!/bin/bash

# Create the folders if they don't exist
mkdir -p exe others

# Move .exe files to 'exe' folder and other files to 'others' folder
for file in *; do
  if [[ -f "$file" ]]; then
    if [[ "$file" == *.exe ]]; then
      mv "$file" exe/
    else
      mv "$file" others/
    fi
  fi
done

# Zip the two folders into malware_sample.zip
zip -r malware_sample.zip exe others

# Output success message
echo "Folders 'exe' and 'others' have been created and zipped into malware_sample.zip."
